"use strict"
const AWS = require('aws-sdk');
const dynamoDb = new AWS.DynamoDB.DocumentClient();
module.exports.delete = (event, context, callback) =>{
  const params = {
    TableName: 'book',
    Key:{
      id: event.pathparameters.id
    }
  };
  dynamoDb.delete(params, (error) =>{
    if(error){
	  console.error(error);
	  callback(new error('couldn\'t delete the book item.'));
	  return;
	}
	const reponse = {
	  statusCode: 200,
	  body: JSON.stringify(result.Item)
	  };
	  callback(null,response);
	});

}