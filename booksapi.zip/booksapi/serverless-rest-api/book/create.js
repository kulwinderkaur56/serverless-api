'use strict';
const uuid= require('uuid');
const AWS = require('aws-sdk');
const dynamoDb = new AWS.DynamoDB.DocumentClient();
module.exports.create = (event, context, callback) =>{
	const timestamp = new Date().getTime();
	const data = JSON.parse(event.body);
	if(typeof data.text !== 'string'){
		console.error('Validation Failed');
		callback(new Error('couldn\'t create the book item.'));
		return;
	}
	const params ={
		TableName: 'book',
		Item:{
			id: uuid.v1(),
			text: data.text,
			checked:false
		}

	}
	dynamoDb.put(params, (error, result) =>{
		if(error){
			console.error(error);
			callback(new error('couldn\'t create the book item.'));
			return;
		}

		const reponse = {
			statusCode: 200,
			body: JSON.stringify(result.Item)
		}
		callback(null,response);
	})

}
