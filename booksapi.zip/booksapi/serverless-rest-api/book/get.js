"use strict"
const AWS = require('aws-sdk');
const dynamoDb = new AWS.DynamoDB.DocumentClient();
module.exports.get = (event, context, callback) =>{
  dynamoDb.scan(params, (error, result) =>{
    if(error){
	  console.error(error);
	  callback(new error('couldn\'t fetch the book items'));
	  return;
	}
	const reponse = {
	  statusCode: 200,
	  body: JSON.stringify(result.Item)
	};
	callback(null, response);
  });

}