"use strict"
const AWS = require('aws-sdk');
const dynamoDb = new AWS.DynamoDB.DocumentClient();
module.exports.update = (event, context, callback) =>{
  // const timestamp = new Date().gettime();
  const data = JSON.parse(event.body);
  if(typeof data.text !== 'string'){
		console.error('Validation Failed');
		callback(new Error('couldn\'t update the book item.'));
		return;
	}
  const params = {
    TableName: 'book',
    Item:{
      id: event.pathparameters.id,
      text:data.text,
      checked: data.checked,
      // updatedAt: timestamp
    }
  }
  dynamoDb.put(params, (error, result) =>{
		if(error){
			console.error(error);
			callback(new error('couldn\'t update the book item.'));
			return;
		}
		const reponse = {
			statusCode: 200,
			body: JSON.stringify(result.Item)
		}
		callback(null,response);
	});

}